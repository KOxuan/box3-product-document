<script setup>
import '/style.css'
</script>
# 小鱼干商城
:::warning
**💡值得注意的是：**

由于小鱼干商城功能涉及商业化，因此仅对**年度创作者**开放。

若你希望获得使用本API的权限，请前往QQ群：**478041977**，联系群主吉吉喵进行申请年度创作者。
:::

### **方法**

#### <font id="API" /><font id="Event">事件</font>onPlayerPurchaseSuccess(<font id="Type">handler:(event:[GamePurchaseSuccessEvent](./shopping#GamePurchaseSuccessEvent))=>void</font>)<font id="Type">: [GameEventHandlerToken](/GameEventHandlerToken/)</font> {#onPlayerPurchaseSuccess}
当玩家成功购买物品时触发

**输入参数**

| **参数** | **必填** | **默认值** | **类型** | **说明** |
| --- | --- | --- | --- | --- |
| handler | _是_ | | function | 监听到玩家购买后的处理函数 |


> 定义于 [#L9904](https://github.com/box3lab/arena_dts/blob/main/GameAPI.d.ts#L9904)


::: details 点击查看示例代码
```javascript
world.onPlayerPurchaseSuccess(({ userId, productId, orderId }) => {
  // 假如商城后台添加了此id的道具，功能为复活道具
  if (productId === 160000000000001) {
    // 由于可能存在多服的情况，每个服都会收到此购买成功的回调，因此需要判断当前服务器有此玩家
    const entity = world.querySelectorAll('player').filter(e => e.player.userId === userId)[0];
    if (entity) {
      entity.player.forceRespawn();
    }  
  }
});
```
:::

## 接口

#### <font id="API" />GamePurchaseSuccessEvent{#GamePurchaseSuccessEvent}
**当玩家成功购买物品时触发的事件**

| **参数** | **类型** | **说明** |
| --- | --- | --- |
| tick | number | 购买成功事件发生的时间 |
| userId | string | 触发购买事件的玩家userId |
| productId | number | 购买商品的ID |
| orderId | number | 购买成功的订单号 |

> 定义于 [#L12867](https://github.com/box3lab/arena_dts/blob/main/GameAPI.d.ts#L12867)