<script setup>
import '/style.css'
</script>
# UI父类
```typescript
declare const ui: UiNode;
```

## 属性

#### <font id="API" />name<font id="Type">: string</font>   {#name}
该节点的标识，可重复。

> 定义于 [#L119](https://github.com/box3lab/arena_dts/blob/main/ClientAPI.d.ts#L119)

---


#### <font id="API" />parent<font id="Type">: UiNode | undefined</font> {#parent}
节点的父节点，非根节点的父节点为空时，该节点将不会被渲染。
>   ℹ️  若节点的父节点为空，且在脚本中无任何引用，则该节点可能会被浏览器当作垃圾回收掉哦。

> 定义于 [#L121](https://github.com/box3lab/arena_dts/blob/main/ClientAPI.d.ts#L121)

---


#### <font id="API" /><font id="ReadOnly">只读</font>children<font id="Type">: ReadonlyArray‹UiNode›</font> {#children}

节点的子节点。如需要调整子节点结构，应修改子节点的`parent`属性。

> 定义于 [#L120](https://github.com/box3lab/arena_dts/blob/main/ClientAPI.d.ts#L120)

---


#### <font id="API" /><font id="ReadOnly">只读</font>events<font id="Type">: [EventEmitter](/GameUI/UiEvent)‹[UiNodeEvents](/GameUI/UiRenderable#事件)›</font> {#events}
管理节点相关的事件。

> 定义于 [#L126](https://github.com/box3lab/arena_dts/blob/main/ClientAPI.d.ts#L126)

---


#### <font id="API" />uiScale<font id="Type">: [UiScale](/GameUI/maths/UiScale) | undefined</font> {#uiScale}
节点等比例缩放数据。

> 定义于 [#L130](https://github.com/box3lab/arena_dts/blob/main/ClientAPI.d.ts#L130)


## 方法

#### <font id="API" />findChildByName(<font id="Type">name: string</font>)<font id="Type">: UiNode | undefined</font> {#findChildByName}
按名称查找子节点，返回对应子节点对象。（节点名称可在编辑模式下的属性面板中查看）

**输入参数**

| **参数** | **必填** | **默认值** | **类型** | **说明** |
| --- | --- | --- | --- | --- |
| name | 是 | | string | 需要查找的节点名称 |

**返回值**

| **类型** | **说明** |
| --- | --- |
| UiNode &#124; undefined | 指定名称的节点的对象，若子节点中无对应ID的节点，则返回`undefined` |

> 定义于 [#L122](https://github.com/box3lab/arena_dts/blob/main/ClientAPI.d.ts#L122)


---


#### <font id="API" />clone()<font id="Type">: this</font> {#clone}
克隆节点，包括其子节点。

**返回值**

| **类型** | **说明** |
| --- | --- |
| this | 返回克隆出来的新节点。 |

> 定义于 [#L134](https://github.com/box3lab/arena_dts/blob/main/ClientAPI.d.ts#L134)


